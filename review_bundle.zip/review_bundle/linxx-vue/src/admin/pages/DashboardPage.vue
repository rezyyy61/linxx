<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Welcome, Admin</h1>
    <p class="text-gray-600">You are logged in to the admin dashboard.</p>
  </div>
</template>
