<template>
  <router-link
      to="/discover"
      class="inline-flex items-center gap-2 px-6 py-2 rounded-full font-semibold transition
           border border-red-500
           text-red-600 hover:text-white bg-white hover:bg-red-600
           dark:text-red-400 dark:bg-transparent dark:hover:bg-red-600 dark:hover:text-white"
  >
    Discover
  </router-link>
</template>

<script>
export default { name: 'HeroCTA' }
</script>
