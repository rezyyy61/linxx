<template>
  <p class="max-w-2xl mx-auto leading-relaxed text-base sm:text-lg
            text-gray-600 dark:text-gray-300">
    Reeoffer cleer Trittter & innoffesonal el polithical social weh Twritter webom craod regnter.
  </p>
</template>

<script>
export default { name: 'HeroSubtitle' }
</script>
