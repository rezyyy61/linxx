<template>
  <div>
    <div class="flex justify-between items-center px-4 pt-3 text-xs text-gray-500 dark:text-gray-400">
      <div v-if="likesCount > 0" class="flex items-center gap-1">
        <ThumbsUp class="w-4 h-4 text-red-500" />
        <span>
          <template v-for="(user, index) in previewNames" :key="user.id">
            {{ user.name }}<span v-if="index < previewNames.length - 1">, </span>
          </template>
          <span v-if="othersCount > 0"> and {{ othersCount }} others</span>
          liked this
        </span>
      </div>

      <div v-if="commentsCount > 0" class="flex items-center gap-1">
        <MessageCircle class="w-4 h-4 text-blue-500" />
        <span>{{ commentsCount }} comment<span v-if="commentsCount > 1">s</span></span>
      </div>
    </div>

    <div class="mt-2 border-t dark:border-gray-700 text-sm text-gray-600 dark:text-gray-300 select-none">
      <div class="flex justify-around items-center px-4 py-2">
        <button
            class="flex items-center gap-1 transition-all duration-200"
            :class="isLiked ? 'text-red-500' : 'hover:text-red-500'"
            @click="handleLike"
        >
          <ThumbsUp :class="['w-5 h-5 transition', isLiked ? 'fill-current text-red-500' : '']" />
        </button>

        <button
            class="flex items-center gap-1 hover:text-blue-500 transition-all duration-200"
            @click="$emit('comment')"
        >
          <MessageCircle class="w-5 h-5" />
          <span>Comment</span>
        </button>

        <button
            ref="shareButton"
            class="flex items-center gap-1 hover:text-green-500 transition-all duration-200"
            @click="onShareClick"
        >
          <Share2 class="w-5 h-5" />
          <span>Share</span>
        </button>
      </div>
    </div>

    <Transition name="fade">
      <div v-if="showLoginPrompt" class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
        <div class="bg-white dark:bg-zinc-900 rounded-2xl shadow-xl w-[90%] max-w-sm px-6 py-8 text-center relative">
          <div class="flex justify-center mb-4">
            <Icon icon="solar:lock-keyhole-minimalistic-linear" class="text-blue-600 dark:text-blue-400" width="40" height="40" />
          </div>
          <h2 class="text-xl font-semibold text-zinc-800 dark:text-zinc-100">Login Required</h2>
          <p class="text-sm text-zinc-600 dark:text-zinc-400 mt-2">
            Please <strong>log in</strong> to continue.
          </p>
          <div class="mt-6 flex justify-center gap-3">
            <button
                @click="showLoginPrompt = false"
                class="px-4 py-2 rounded-lg border border-gray-300 dark:border-zinc-600 text-sm text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 transition"
            >
              Cancel
            </button>
            <button
                @click="router.push({ name: 'login' })"
                class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm transition"
            >
              Log in
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { Icon } from '@iconify/vue'
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ThumbsUp, MessageCircle, Share2 } from 'lucide-vue-next'
import { useAuthStore } from '@/stores/auth'
import { useLikesStore } from '@/stores/useLikesStore'

const props = defineProps({
  post: { type: Object, required: true }
})

const emit = defineEmits(['like', 'comment', 'share'])

const router = useRouter()
const authStore = useAuthStore()
const likesStore = useLikesStore()

const showLoginPrompt = ref(false)
const shareButton = ref(null)

const isLoggedIn = computed(() => !!(authStore.user?.id ?? authStore.user?.data?.id))

onMounted(() => {
  likesStore.setInitial(
      props.post.id,
      props.post.is_liked,
      props.post.likes_count,
      props.post.likes_preview
  )
})

const isLiked = computed(() => likesStore.isLiked(props.post.id))
const likesCount = computed(() => likesStore.likesCount(props.post.id))
const previewNames = computed(() => likesStore.previewNames(props.post.id))
const othersCount = computed(() => likesCount.value - previewNames.value.length)
const commentsCount = ref(props.post.comments_count ?? 0)

const handleLike = () => {
  if (!isLoggedIn.value) {
    showLoginPrompt.value = true
    return
  }
  likesStore.toggle(props.post.id)
}

const onShareClick = () => {
  if (!isLoggedIn.value) {
    showLoginPrompt.value = true
    return
  }
  const el = shareButton.value
  const rect = el ? el.getBoundingClientRect() : { top: 0, left: 0, width: 0, height: 0 }
  emit('share', {
    top: rect.top + window.scrollY,
    left: rect.left + rect.width / 2
  })
}
</script>

<style scoped>
.fade-enter-active, .fade-leave-active { transition: opacity .3s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
